package com.braindatawire.collegemanagement.service;

public interface Cjc 
{
	public void addCourse();
	public void viewCourse();
	public void addFaculty();
	public void viewFaculty();
	public void addBatch();
	public void viewBatch();
	public void addStudent();
	public void viewStudent();

}
